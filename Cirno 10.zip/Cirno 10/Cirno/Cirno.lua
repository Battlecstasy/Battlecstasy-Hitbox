local Cirno = {}
local CirnoWalkSpeed = 1.2
local CirnoWalkSpeedBack = 1.2
local CirnoDashSpeed = 1.2
local CirnoGravity = 0.8
local CirnoJump = 1.1 
local CirnoHP = 90
local CirnoAnimationFrame ={}
local CirnoAnimationTime = 0
local animationsize = {8,8,2,6,9,3,2,2,6,3,4,4,7,8,5,2,7,5,8,4,6,6,13,5,13,14,10,26,23,14,32}
local Cirno_count = 1
local anim_type=0
local CirnoState=0 --Estado da Cirno. 0 é normal, 1 é no ar, 2 é em hitstun, 3 é caido, 4 é guardando
local StageHeight = 300
local Charbx=400
local Charby=StageHeight
CirnoYSpeed = 0

function Cirno:new()
  for i=1,31 do
    for j=1,animationsize[i] do
      CirnoAnimationFrame[i][j]={love.graphics.newImage("Cirno/Cirnosprite/Cirno"..Cirno_count..".png")}
      Cirno_count=Cirno_count+1
    end
  end
end

function CirnoWalkForward()
  anim_type=1
  Charbx= Charbx + 100*CirnoWalkSpeed 
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 8 then
    sprite= 1
  end
end

function CirnoWalkBackward()
  CirnoAnimationTime=CirnoAnimationTime+dt
  animtype=2
  Charbx= Charbx - 100*CirnoWalkSpeed 
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 8 then
    sprite= 1
  end
end

function CirnoStandUp()
  anim_type=3
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 2 then
    sprite= 1
  end
end

function CirnoStand()
  anim_type=4
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 6 then
    sprite= 1
  end
end

function CirnoLanding()
  CirnoState=0
  anim_type=5
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 3 then
    sprite= 1
  end
end
function CirnoLandingOnGround()
  CirnoState=-1
  anim_type=6
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 9 then
    sprite=9
    CirnoState=3
  end
end
function CirnoJumpForward()
  CirnoYSpeed=-200
  CirnoState=1
  anim_type=7
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 2 then
    sprite=1
  end
end
function CirnoJumpBackward()
  CirnoYSpeed=-200
  CirnoState=1
  anim_type=8
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 2 then
    sprite=1
  end
end
function CirnoJump()
  CirnoState=1
  CirnoYSpeed=-200
  anim_type=9
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 6 then
    sprite=1
  end
end
function CirnoHitLow()
  CirnoState=2
  anim_type=11
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 4 then
    sprite=1
    CirnoState=0
  end
end
function CirnoHitHigh()
  CirnoState=2
  anim_type=12
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 4 then
    sprite=1
    CirnoState=0
  end
end
function CirnoHitAir()
  CirnoState=2
  anim_type=13
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 7 then
    sprite=7
  end
end
function CirnoGuard()
  CirnoState=4
  anim_type=14
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 8 then
    sprite=1
  end
end
function CirnoGettingBackUp()
  anim_type=15
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 5 then
    sprite=1
    CirnoState=0
  end
end
function CirnoFalling()
  anim_type=16
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 2 then
    sprite=1
  end
  if love.keyboard.isDown(right) then
    Charbx=Charbx+10*CirnoWalkSpeed
  elseif love.keyboard.isDown(right) then
    Charbx=Charbx-10*CirnoWalkSpeed
  end
end
function CirnoDashForward()
  anim_type=17
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 7 then
    sprite=1
  end
end
function CirnoDashBackward()
  anim_type=18
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 5 then
    sprite=1
  end
end
function CirnoCrouchGuard()
  CirnoState=4
  anim_type=19
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 8 then
    sprite=1
  end
end
function CirnoCrouch()
  anim_type=20
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 4 then
    sprite=1
  end
end
function CirnoNeutralWeak()
  anim_type=21
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 6 then
    sprite=1
  end
end
function CirnoNeutralMedium()
  anim_type=22
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 6 then
    sprite=1
  end
end
function CirnoNeutralHeavy()
  anim_type=23
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 13 then
    sprite=1
  end
end
function CirnoCrouchingWeak()
  anim_type=24
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 5 then
    sprite=1
  end
end
function CirnoCrouchingMedium()
  anim_type=25
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 13 then
    sprite=1
  end
end
function CirnoCrouchingHeavy()
  anim_type=26
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 14 then
    sprite=1
  end
end
function CirnoAirWeak()
  anim_type=27
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 10 then
    sprite=1
  end
end
function CirnoAirMedium()
  anim_type=28
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 26 then
    sprite=1
  end
end
function CirnoAirHeavy()
  anim_type=29
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 23 then
    sprite=1
  end
end
function CirnoSpecial()
  anim_type=30
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 14 then
    sprite=1
  end
end
function CirnoSuper()
  anim_type=31
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 32 then
    sprite=1
  end
end
function Cirno:update(dt)
  Charby=Charby+CirnoYSpeed
  CirnoYSpeed=CirnoYSpeed+CirnoGravity*10
  if Charby>StageHeight then
    Charby=StageHeight
    CirnoYSpeed=0
  end
  if CirnoYSpeed>0 then
    CirnoFalling()
  end
  if CirnoState == 0 then
    if love.keyboard.isDown(right) then
      CirnoWalkForward()
      if love.keyboard.isDown(up) then
        CirnoJumpForward()
      end
    end
    if love.keyboard.isDown(left) then
      CirnoWalkBackward()
      if love.keyboard.isDown(left) then
        CirnoJumpBackward()
      end
    end
    if love.keyboard.isDown(down) then
      CirnoCrouch()
      if love.keyboard.isDown(z) then
        CirnoCrouchingWeak()
      end
      if love.keyboard.isDown(x) then
        CirnoCrouchingMedium()
      end
      if love.keyboard.isDown(c) then
        CirnoCrouchingHeavy()
      end
    end
    if love.keyboard.isDown(up) then
      CirnoJump()
    end
    if love.keyboard.isDown(z) then
      CirnoNeutralWeak()
    end 
    if love.keyboard.isDown(x) then
      CirnoNeutralMedium()
    end
    if love.keyboard.isDown(c) then
      CirnoNeutralHeavy()
    end
    if love.keyboard.isDown(a) then
      CirnoSpecial()
    end
    if love.keyboard.isDown(s) then
      CirnoSuper()
    end

  elseif CirnoState == 1 then
    if love.keyboard.isDown(z) then
      CirnoAirWeak()
    end
    if love.keyboard.isDown(x) then
      CirnoAirMedium()
    end
    if love.keyboard.isDown(c) then
      CirnoAirHeavy()
    end
  elseif CirnoState == 3 then
    if love.keyboard.isDown(up) then
      CirnoGettingBackUp()
    end
  else
    CirnoStand()
  end
end
function Cirno:draw(anim_type, sprite, charb_x, charb_y, prop)
  love.graphics.draw(CirnoAnimationFrame[anim_type][sprite], charb_x, charb_y, 0, prop)
end
local Chun_li_vida=100
local Chun_li_velocidade=1
local Chun_li_gravidade=1
local Chun_li_andar=100
local Chun_li_anim_frame = 1
local Chun_li_pos_x = 30
local Chun_li_pos_y = 50
local Chun_li = {}
local Chun_li_attack = {}
local Chun_li_anim_time = 0
local Chun_li_anim_number = {16, 16, 11, 5}
local cl_count = 1
local cl_anim_type = 0
local cl_dt
local cl_key

function love.load()
  for x = 1, 4 do -- carrega as imagens da animação
    Chun_li[x] = {}
      for y = 1, Chun_li_anim_number[x] do
        Chun_li[x][y]=love.graphics.newImage("Chun-li_" ..cl_count.. ".png")
        cl_count = cl_count+1
       end
  end
end
function ChunLiNeutroFraco(cl_dt)
  cl_anim_type=4
  Chun_li_anim_time=Chun_li_anim_time+cl_dt
  if Chun_li_anim_time > 0.15 then
    Chun_li_anim_time = 0
    Chun_li_anim_frame=Chun_li_anim_frame+1
  end
  if Chun_li_anim_frame>5 then
    Chun_li_anim_frame=1
  end
end

function ClStand(cl_dt)
  cl_anim_type=3
 Chun_li_anim_time=Chun_li_anim_time+cl_dt
  if Chun_li_anim_time > 0.15 then
    Chun_li_anim_time = 0
    Chun_li_anim_frame=Chun_li_anim_frame+1
  end
  if Chun_li_anim_frame> 6 then
    Chun_li_anim_frame= 1
  end
  end

function love.keypressed(key)
  cl_key = key
  if cl_key ~= key then
    cl_key = 0
  end
  --[[if key=="f" then 
   ChunLiNeutroFraco(cl_dt)
 end]]
end

function love.update(dt)
  cl_dt = dt
  if love.keyboard.isDown("right") then
    cl_anim_type = 1
    Chun_li_pos_x = Chun_li_pos_x + (100 * dt) -- movimenta o personagem
    Chun_li_anim_time = Chun_li_anim_time + dt
    
    if Chun_li_anim_time > 0.06 then -- quando acumular mais de 0.1
      Chun_li_anim_frame = Chun_li_anim_frame + 1 -- avança para proximo frame
      Chun_li_anim_time = 0
    end
    
    if Chun_li_anim_frame > 16 then
      Chun_li_anim_frame = 1
    end
    
  elseif love.keyboard.isDown("left") then
    cl_anim_type = 2
    Chun_li_pos_x = Chun_li_pos_x + (-100 * dt) -- movimenta o personagem
    
    Chun_li_anim_time = Chun_li_anim_time + dt
    if Chun_li_anim_time > 0.06 then -- quando acumular mais de 0.1
      Chun_li_anim_frame = Chun_li_anim_frame + 1 -- avança para proximo frame
      Chun_li_anim_time = 0
    end
    
    if Chun_li_anim_frame > 16 then
      Chun_li_anim_frame = 1
    end
  elseif cl_key == "f" then 
   ChunLiNeutroFraco(dt)
  else
   ClStand(dt)
  end
end

function love.draw()
  love.graphics.draw(Chun_li[cl_anim_type][Chun_li_anim_frame], Chun_li_pos_x, Chun_li_pos_y)
end

 
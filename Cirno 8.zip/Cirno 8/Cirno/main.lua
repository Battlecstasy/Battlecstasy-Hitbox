local Cirno = {}
local CirnoGravity = 0.8
local CirnoJump = 1.1 
local CirnoHP = 90
local CirnoAnimationFrame ={}
local CirnoAnimationTime = 0
local animationsize = {8,8,2,6,9,3,2,2,6,3,4,4,7,8,5,2,7,5,8,4,6,6,13,5,13,14,10,26,23,14,32}
local Cirno_count = 1
local anim_type=4
local CirnoState=0 --Estado da Cirno. 0 é normal, 1 é no ar, 2 é em hitstun, 3 é caido, 4 é guardando, 5 é atacando, 6 é atacando no ar, 7 é agachada, 8 é atacando agachada
local StageHeight = 300
local Charbx=400
local Charby=StageHeight
local CirnoXSpeed = 0
local CirnoYSpeed = 0
local sprite = 1
local sprite2 = 1
local GenericVariable = 0
local GenericVariableAtk = 0
local CirnoAttacktype = 0
local SpecialEffects =0
local SpecialEffectX =0
local SpecialEffectY =0

function love.load()
  for i=1,31 do
    CirnoAnimationFrame[i] = {}
    for j=1,animationsize[i] do
      CirnoAnimationFrame[i][j]=love.graphics.newImage("Cirno/Cirnosprite/Cirno"..Cirno_count..".png")
      Cirno_count=Cirno_count+1
    end
  end
end

function CirnoWalkForward(dt)
  anim_type=1
  CirnoXSpeed=120
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 8 then
    sprite= 1
    CirnoXSpeed=0
  end
end

function CirnoWalkBackward(dt)
  CirnoAnimationTime=CirnoAnimationTime+dt
  anim_type=2
  CirnoXSpeed=-120
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 8 then
    sprite= 1
    CirnoXSpeed=0
  end
end

function CirnoStandUp(dt)
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  anim_type=3
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite= 1
    CirnoState=0
    GenericVariable=0
  end
end

function CirnoStand(dt)
  CirnoXSpeed=0
  anim_type=4
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 6 then
    sprite= 1
  end
end

function CirnoLanding(dt)
  CirnoXSpeed=0
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  anim_type=6
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 3 then
    sprite= 1
    CirnoState=0
    GenericVariable=0
  end
end
function CirnoLandingOnGround(dt)
  anim_type=5
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 9 then
    sprite=9
    CirnoState=0
  end
end
function CirnoJumpForward(dt)
  if CirnoState==0 then
    CirnoYSpeed=-400
  end
  CirnoState=1
  anim_type=7
  CirnoXSpeed=120
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
    CirnoXSpeed=0
  end
end
function CirnoJumpBackward(dt)
  if CirnoState==0 then
    CirnoYSpeed=-400
  end
  CirnoState=1
  anim_type=8
  CirnoXSpeed=-120
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
    CirnoXSpeed=0
  end
end
function CirnoJump(dt)
  CirnoXSpeed=0
  if CirnoState==0 then
    CirnoYSpeed=-400
  end
  CirnoState=1
  anim_type=9
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 6 then
    sprite=6
  end
end
function CirnoHitLow(dt)
  CirnoState=2
  anim_type=11
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    sprite=1
    CirnoState=0
  end
end
function CirnoHitHigh(dt)
  CirnoState=2
  anim_type=12
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    sprite=1
    CirnoState=0
  end
end
function CirnoHitAir(dt)
  CirnoState=2
  anim_type=13
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 7 then
    sprite=7
  end
end
function CirnoGuard(dt)
  CirnoState=4
  anim_type=14
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 8 then
    sprite=1
  end
end
function CirnoGettingBackUp(dt)
  anim_type=15
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 5 then
    sprite=1
    CirnoState=0
  end
end
function CirnoFalling(dt)
  anim_type=16
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
  end
  if love.keyboard.isDown("right") then
    CirnoXSpeed=120
  elseif love.keyboard.isDown("left") then
    CirnoXSpeed=-120
  else CirnoXSpeed=0
  end
end
function CirnoDashForward(dt)
  anim_type=17
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 7 then
    sprite=1
  end
end
function CirnoDashBackward(dt)
  anim_type=18
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 5 then
    sprite=1
  end
end
function CirnoCrouchGuard(dt)
  CirnoState=4
  anim_type=19
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 8 then
    sprite=1
  end
end
function CirnoCrouch(dt)
  CirnoXSpeed=0
  CirnoState=7
  anim_type=20
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    sprite=4
  end
end
function CirnoNeutralWeak(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=1
  CirnoState=5
  anim_type=21
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 6 then
    sprite=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoNeutralMedium(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=2
  CirnoState=5
  anim_type=22
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.10 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 4 then
    SpecialEffects=1
    sprite2=6
    GenericVariable=GenericVariable+1
    CirnoXSpeed=500
  end
  if sprite > 5 then
    sprite = 5
  end
  if GenericVariable==300 then
    CirnoXSpeed=0
    SpecialEffects=0
    sprite=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
  end
end
function CirnoNeutralHeavy(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=3
  CirnoState=5
  anim_type=23
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite >3 then
    SpecialEffectX=25
    SpecialEffectY=-10
    SpecialEffects=3
    sprite2=12
  end
  if sprite >5 then
    SpecialEffects=0
  end
  if sprite > 11 then
    sprite=1
    sprite2=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
    SpecialEffectX=0
    SpecialEffectY=0
  end
end
function CirnoCrouchingWeak(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=1
  CirnoState=8
  anim_type=24
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 5 then
    sprite=4
    CirnoState=7
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoCrouchingMedium(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=2
  CirnoState=8
  anim_type=25
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 13 then
    sprite=4
    CirnoState=7
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoCrouchingHeavy(dt)
  CirnoXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=3
  CirnoState=8
  anim_type=26
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite >3 then
    SpecialEffects=2
    SpecialEffectY=-80
    sprite2=14
    CirnoXSpeed=100
    GenericVariable=GenericVariable+1
    if GenericVariable<300 and sprite>8 then
      sprite=8
    end
  end
  if sprite==6 then
    SpecialEffectX=60
    SpecialEffectY=-60
  end
  if sprite>6 then
    SpecialEffectX=80
    SpecialEffectY=0
  end
  if sprite>8 then
    CirnoXSpeed=0
  end
  if sprite > 13 then
    sprite=1
    CirnoState=7
    CirnoAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
    SpecialEffects=0
    SpecialEffectX=0
    SpecialEffectY=0
  end
end
function CirnoAirWeak(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=1
  CirnoState=6
  anim_type=27
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 10 then
    sprite=1
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoAirMedium(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=2
  CirnoState=6
  anim_type=28
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 26 then
    sprite=1
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoAirHeavy(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=3
  CirnoState=6
  anim_type=29
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 23 then
    sprite=1
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoSpecial(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=4
  CirnoState=5
  anim_type=30
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 14 then
    sprite=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function CirnoSuper(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  CirnoAttacktype=5
  CirnoState=5
  anim_type=31
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
    CirnoAnimationTime = 0
  end
  if sprite > 32 then
    sprite=1
    CirnoState=0
    CirnoAttacktype=0
    GenericVariableAtk=0
  end
end
function love.update(dt)
  Charbx=Charbx+CirnoXSpeed*dt
  CirnoYSpeed=CirnoYSpeed+CirnoGravity*500*dt
  Charby=Charby+CirnoYSpeed*dt
  if Charby>StageHeight then
    Charby=StageHeight
    CirnoYSpeed=0
    if CirnoState==1 or CirnoState==6 then
      CirnoLanding(dt)
      CirnoAttacktype=0
    end
  end
  if CirnoState == 0 then
    if love.keyboard.isDown("z") then
      CirnoNeutralWeak(dt)
    elseif love.keyboard.isDown("x") then
      CirnoNeutralMedium(dt)
    elseif love.keyboard.isDown("c") then
      CirnoNeutralHeavy(dt)
    elseif love.keyboard.isDown("a") then
      CirnoSpecial(dt)
    elseif love.keyboard.isDown("s") then
      CirnoSuper(dt)
    elseif love.keyboard.isDown("right") then
      CirnoWalkForward(dt)
      if love.keyboard.isDown("up") then
        sprite=1
        CirnoJumpForward(dt)
      end
    elseif love.keyboard.isDown("left") then
      CirnoWalkBackward(dt)
      if love.keyboard.isDown("up") then
        sprite=1
        CirnoJumpBackward(dt)
      end
    elseif love.keyboard.isDown("down") then
      sprite=1
      CirnoCrouch(dt)
    elseif love.keyboard.isDown("up") then
      sprite=1
      CirnoJump(dt)
    else
      CirnoStand(dt)
    end
  elseif CirnoState == 1 then
    if CirnoYSpeed<0 then
      if love.keyboard.isDown("left") then
        CirnoJumpBackward(dt)
      elseif love.keyboard.isDown("right") then
        CirnoJumpForward(dt)
      else CirnoJump(dt)
      end
    end
    if CirnoYSpeed>0 then
      CirnoFalling(dt)
    end
    if love.keyboard.isDown("z") then
      CirnoAirWeak(dt)
    elseif love.keyboard.isDown("x") then
      CirnoAirMedium(dt)
    elseif love.keyboard.isDown("c") then
      CirnoAirHeavy(dt)
    end
  elseif CirnoState == 3 then
    if love.keyboard.isDown("up") then
      CirnoGettingBackUp(dt)
    end
  elseif CirnoState == 5 then
    if CirnoAttacktype == 1 then
      CirnoNeutralWeak(dt)
    elseif CirnoAttacktype == 2 then
      CirnoNeutralMedium(dt)
    elseif CirnoAttacktype == 3 then
      CirnoNeutralHeavy(dt)
    elseif CirnoAttacktype == 4 then
      CirnoSpecial(dt)
    elseif CirnoAttacktype == 5 then
      CirnoSuper(dt)
    end
  elseif CirnoState == 6 then
    if CirnoAttacktype == 1 then
      CirnoAirWeak(dt)
    elseif CirnoAttacktype == 2 then
      CirnoAirMedium(dt)
    elseif CirnoAttacktype == 3 then
      CirnoAirHeavy(dt)
    end
  elseif CirnoState==8 then
    if CirnoAttacktype == 1 then
      CirnoCrouchingWeak(dt)
    elseif CirnoAttacktype == 2 then
      CirnoCrouchingMedium(dt)
    elseif CirnoAttacktype == 3 then
      CirnoCrouchingHeavy(dt)
    end
  elseif CirnoState == 7 then
    if love.keyboard.isDown("down") then
      CirnoCrouch(dt)
      if love.keyboard.isDown("z") then
        CirnoCrouchingWeak(dt)
      elseif love.keyboard.isDown("x") then
        CirnoCrouchingMedium(dt)
      elseif love.keyboard.isDown("c") then
        CirnoCrouchingHeavy(dt)
      end
    else
      CirnoStandUp(dt)
    end
  end
end
function love.draw(--[[charb_x, charb_y, prop]])
  if SpecialEffects==1 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx, Charby, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
  elseif SpecialEffects==2 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
  elseif SpecialEffects==3 then
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 0.6, 0.6, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.draw(CirnoAnimationFrame[anim_type][sprite2+1], Charbx+SpecialEffectX+-40, Charby+SpecialEffectY+40, 0, 0.6, 0.6, (CirnoAnimationFrame[anim_type][sprite2]:getWidth()-CirnoAnimationFrame[anim_type][sprite]:getWidth())/2, (CirnoAnimationFrame[anim_type][sprite2]:getHeight()-CirnoAnimationFrame[anim_type][sprite]:getHeight())/2)
  end
  love.graphics.draw(CirnoAnimationFrame[anim_type][sprite], Charbx, Charby--[[, 0, prop]])
end

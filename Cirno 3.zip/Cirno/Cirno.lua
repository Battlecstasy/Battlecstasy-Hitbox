local Cirno = {}
local CirnoWalkSpeed = 1.2
local CirnoWalkSpeedBack = 1.2
local CirnoDashSpeed = 1.2
local CirnoGravity = 0.8
local CirnoJump = 1.1 
local CirnoHP = 90
local CirnoAnimationFrame ={}
local animationsize = {8,8,2,6,9,3,2,2,6,3,4,4,7,8,5,2,7,5,8,4,6,6,13,5,13,14,10,26,23,14,32}
local Cirno_count = 1
function Cirno:new()
 for i=1,31 do
   for j=1,animationsize[i] do
    CirnoAnimationFrame[i][j]={love.graphics.newImage("Cirno/Cirnosprite/Cirno"..Cirno_count..".png")}
    Cirno_count=Cirno_count+1
   end
 end
end


function Cirno:draw(anim_type, sprite, charb_x, charb_y, prop)
  love.graphics.draw(CirnoAnimationFrame[anim_type][sprite], charb_x, charb_y, 0, prop)
end
return Cirno
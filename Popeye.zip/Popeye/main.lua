local health=110
local speed=0,95
local grav=1
local popeye_walk={}
local popeye_attack_aereo={}
local popeye_attack_forte={}
local popeye_attack_super={}
local popeye_attack_special={}
local popeye_attack_leve={}
local popeye_attack_medio={}
local popeye_anim_frame=1
local popeye_pos_x = 30
local popeye_pos_y = 400
local popeye_anim_time=0
local popeye_stand={}


function love.load()
 for x=1,9,1 do
   popeye_walk[x]=love.graphics.newImage("Walk_11-0"..x..".png")  
   end
 

function love.update(dt)
if love.keyboard.isDown("right") then
  popeye_pos_x= popeye_pos_x+(100*dt)
  popeye_anim_time = popeye_anim_time + dt
if popeye_anim_time > 0.12 then 
popeye_anim_frame = popeye_anim_frame + 1 
  if popeye_anim_frame>9 then
    popeye_anim_frame=1
      end              
      popeye_anim_time=0
    end
    
  if love.keyboard.isDown("left") then
  popeye_pos_x= popeye_pos_x+(-100*dt)
  popeye_anim_frame = popeye_anim_frame + 1 
  if popeye_anim_frame>9 then
    popeye_anim_frame=1
      end
      popeye_anim_time=0
    end
  
  end
end

function love.draw()love.graphics.draw(popeye_walk[popeye_anim_frame],popeye_pos_x,popeye_pos_y)
  end
end
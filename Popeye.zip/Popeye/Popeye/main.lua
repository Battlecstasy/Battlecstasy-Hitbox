local Popeye = {}
local PopeyeGravity = 1.0
local PopeyeJump = 0.9
local PopeyeHP = 90
local PopeyeAnimationFrame ={}
local PopeyeAnimationTime = 0
local animationsize = {5,9,9,2,1,3,3,4,3,24,18,4,3,4,4,9,4,3,1,3}
local Popeye_count = 1
local anim_type=1
local PopeyeState=0 --Estado do Popeye. 0 é normal, 1 é no ar, 2 é em hitstun, 3 é caido, 4 é guardando, 5 é atacando, 6 é atacando no ar, 7 é agachaoa, 8 é atacando agachado, 9 é dash
local StageHeight = 300
local Charbx=400
local Charby=StageHeight
local PopeyeXSpeed = 0
local PopeyeYSpeed = 0
local sprite = 1
local sprite2 = 1
local GenericVariable = 0
local GenericVariableAtk = 0
local PopeyeAttacktype = 0
local SpecialEffects =0
local SpecialEffectX =0
local SpecialEffectY =0
local EnemyState = 5
local Guardtype=0
local hitboxX=65
local hitboxY=80

function love.load()
  for i=1,20 do
    PopeyeAnimationFrame[i] = {}
    for j=1,animationsize[i] do
      PopeyeAnimationFrame[i][j]=love.graphics.newImage("Popeyesprite/Popeye/pp"..Popeye_count..".png")
      Popeye_count=Popeye_count+1
    end
  end




end
function PopeyeWalkForward(dt)
  anim_type=4
  PopeyeXSpeed=120
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 8 then
    sprite= 1
    PopeyeXSpeed=0
  end
end

function PopeyeWalkBackward(dt)
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  anim_type=2
  PopeyeXSpeed=-120
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 8 then
    sprite= 1
    PopeyeXSpeed=0
  end
end

function PopeyeStandUp(dt)
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  anim_type=3
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 2 then
    sprite= 1
    PopeyeState=0
    GenericVariable=0
  end
end

function PopeyeStand(dt)
  PopeyeXSpeed=0
  anim_type=1
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.20 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 5 then
    sprite= 1
  end
end

function PopeyeLanding(dt)
  PopeyeXSpeed=0
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  anim_type=6
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 3 then
    sprite= 1
    PopeyeState=0
    GenericVariable=0
  end
end
function PopeyeLandingOnGround(dt)
  anim_type=5
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 9 then
    sprite=9
    PopeyeState=0
  end
end
function PopeyeJumpForward(dt)
  if PopeyeState==0 then
    PopeyeYSpeed=-400
  end
  PopeyeState=1
  anim_type=7
  PopeyeXSpeed=120
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
    PopeyeXSpeed=0
  end
end
function PopeyeJumpBackward(dt)
  if PopeyeState==0 then
    PopeyeYSpeed=-400
  end
  PopeyeState=1
  anim_type=8
  PopeyeXSpeed=-120
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
    PopeyeXSpeed=0
  end
end
function PopeyeJump(dt)
  PopeyeXSpeed=0
  if PopeyeState==0 then
    PopeyeYSpeed=-400
  end
  PopeyeState=1
  anim_type=9
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 6 then
    sprite=6
  end
end
function PopeyeHitLow(dt)
  PopeyeState=2
  anim_type=11
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 4 then
    sprite=1
    PopeyeState=0
  end
end
function PopeyeHitHigh(dt)
  PopeyeState=2
  anim_type=12
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 4 then
    sprite=1
    PopeyeState=0
  end
end
function PopeyeHitAir(dt)
  PopeyeState=2
  anim_type=13
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 7 then
    sprite=7
  end
end
function PopeyeGuard(dt)
  SpecialEffects=9
  SpecialEffectX=50
  if GenericVariable==0 then
    sprite2=5
    GenericVariable=1
  end
  PopeyeState=4
  Guardtype=0
  PopeyeXSpeed=0
  anim_type=14
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    if GenericVariable==0 then
      sprite2=5
      GenericVariable=1
    end
    sprite2=sprite2+1
    PopeyeAnimationTime = 0
  end
  if sprite > 2 and GenericVariable==1 then
    sprite=1
  end
  if sprite2>8 then
    sprite2=5
  end
  if love.keyboard.isDown("down") then
    PopeyeCrouchGuard(dt)
  end
  if not love.keyboard.isDown("left") then
    GenericVariable=2
  end
  if sprite>3 then
    sprite=1
    sprite2=1
    PopeyeState=0
    Guardtype=0
    SpecialEffects=0
    SpecialEffectX=0
    GenericVariable=0
  end
end
function PopeyeGettingBackUp(dt)
  anim_type=15
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 5 then
    sprite=1
    PopeyeState=0
  end
end
function PopeyeFalling(dt)
  anim_type=16
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 2 then
    sprite=1
  end
  if love.keyboard.isDown("right") then
    PopeyeXSpeed=120
  elseif love.keyboard.isDown("left") then
    PopeyeXSpeed=-120
  else PopeyeXSpeed=0
  end
end
function PopeyeDashForward(dt)
  PopeyeState=9
  anim_type=17
  PopeyeXSpeed=0
  if GenericVariable==0 then
    sprite=1
    GenericVariable=1
  end
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 2 then
    PopeyeXSpeed=240
  end
  if sprite > 6 and love.keyboard.isDown("d") and love.keyboard.isDown("right") then
    sprite=3
  elseif sprite>6 then
    PopeyeXSpeed=0
  end
  if not love.keyboard.isDown("d") or not love.keyboard.isDown("right") then
    if sprite < 7 then
      sprite=7
    end
  end
  if sprite > 7 then
    sprite=1
    GenericVariable=0
    PopeyeXSpeed=0
    PopeyeState=0
  end
end
function PopeyeDashBackward(dt)
  PopeyeState=9
  anim_type=18
  PopeyeXSpeed=0
  if GenericVariable==0 then
    sprite=1
    GenericVariable=2
  end
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 0 then
    PopeyeXSpeed=-240
  end
  if sprite > 4 and love.keyboard.isDown("d") and love.keyboard.isDown("left") then
    sprite=1
  elseif sprite>4 then
    PopeyeXSpeed=0
  end
  if not love.keyboard.isDown("d") or not love.keyboard.isDown("left") then
    if sprite < 5 then
      sprite=5
    end
  end
  if sprite > 5 then
    sprite=1
    GenericVariable=0
    PopeyeXSpeed=0
    PopeyeState=0
  end
end
function PopeyeCrouchGuard(dt)
  SpecialEffects=9
  if GenericVariable==0 then
    sprite2=5
    GenericVariable=1
  end
  SpecialEffectX=50
  PopeyeState=4
  Guardtype=1
  PopeyeXSpeed=0
  anim_type=19
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    sprite2=sprite2+1
    PopeyeAnimationTime = 0
  end
  if sprite > 2 and GenericVariable==1 then
    sprite=1
  end
  if sprite2>8 then
    sprite2=5
  end
  if not love.keyboard.isDown("left") then
    GenericVariable=2
  end
  if not love.keyboard.isDown("down") then
    PopeyeGuard(dt)
  end
  if sprite>3 then
    sprite=1
    sprite2=1
    PopeyeState=0
    Guardtype=0
    SpecialEffects=0
    SpecialEffectX=0
    GenericVariable=0
  end
end
function PopeyeCrouch(dt)
  PopeyeXSpeed=0
  PopeyeState=7
  anim_type=20
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 4 then
    sprite=4
  end
end
function PopeyeNeutralWeak(dt)
  PopeyeXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeAttacktype=1
  PopeyeState=5
  anim_type=21
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.05 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 6 then
    sprite=1
    PopeyeState=0
    PopeyeAttacktype=0
    GenericVariableAtk=0
  end
end
function PopeyeNeutralHeavy(dt)
  PopeyeXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeAttacktype=3
  PopeyeState=5
  anim_type=22
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 4 then
    SpecialEffects=1
    sprite2=6
    GenericVariable=GenericVariable+5*dt
    PopeyeXSpeed=500
  end
  if sprite > 5 then
    sprite = 5
  end
  if GenericVariable>3 then
    PopeyeXSpeed=0
    SpecialEffects=0
    sprite=1
    PopeyeState=0
    PopeyeAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
  end
end
function PopeyeNeutralMedium(dt)
  PopeyeXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeAttacktype=2
  PopeyeState=5
  anim_type=23
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite >3 then
    SpecialEffectX=25
    SpecialEffectY=-10
    SpecialEffects=3
    sprite2=12
  end
  if sprite >5 then
    SpecialEffects=0
  end
  if sprite > 11 then
    sprite=1
    sprite2=1
    PopeyeState=0
    PopeyeAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
    SpecialEffectX=0
    SpecialEffectY=0
  end
end
function PopeyeCrouchingWeak(dt)
  PopeyeXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeAttacktype=1
  PopeyeState=8
  anim_type=24
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.05 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 5 then
    sprite=4
    PopeyeState=7
    PopeyeAttacktype=0
    GenericVariableAtk=0
  end
end
function PopeyeCrouchingMedium(dt)
  PopeyeXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeAttacktype=2
  PopeyeState=8
  anim_type=25
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.125 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite>=2 then
    SpecialEffects=4
    GenericVariable=GenericVariable+7.5*dt
    sprite2=11
    SpecialEffectX=110
    SpecialEffectY=40
    PopeyeXSpeed=150
  end
  if not love.keyboard.isDown("x") then
    sprite=1
    PopeyeState=7
    PopeyeAttacktype=0
    GenericVariableAtk=0
    SpecialEffects=0
    GenericVariable=0
    SpecialEffectX=0
    SpecialEffectY=0
    PopeyeXSpeed=0
  end
  if sprite>10 and love.keyboard.isDown("x") then
    sprite=2
  end
end
function PopeyeCrouchingHeavy(dt)
  PopeyeXSpeed=0
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeAttacktype=3
  PopeyeState=8
  anim_type=26
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite >3 then
    SpecialEffects=2
    SpecialEffectY=-80
    sprite2=14
    PopeyeXSpeed=100
    GenericVariable=GenericVariable+2*dt
    if GenericVariable<1 and sprite>8 then
      sprite=8
    end
  end
  if sprite==6 then
    SpecialEffectX=60
    SpecialEffectY=-60
  end
  if sprite>6 then
    SpecialEffectX=80
    SpecialEffectY=0
  end
  if sprite>8 then
    PopeyeXSpeed=0
    SpecialEffects=0
  end
  if sprite > 13 then
    sprite=1
    PopeyeState=7
    PopeyeAttacktype=0
    GenericVariableAtk=0
    GenericVariable=0
    SpecialEffectX=0
    SpecialEffectY=0
  end
end
function PopeyeAirWeak(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeAttacktype=1
  PopeyeState=6
  anim_type=27
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.05 then
    sprite=sprite+1
    PopeyeAnimationTime = 0
  end
  if sprite > 10 then
    sprite=1
    PopeyeAttacktype=0
    GenericVariableAtk=0
    PopeyeState=1
  end
end
function PopeyeAirMedium(dt)
  if GenericVariableAtk==0 then
    sprite=1
    sprite2=8
    GenericVariableAtk=1
  end
  PopeyeAttacktype=2
  PopeyeState=6
  anim_type=28
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.05 then
    sprite=sprite+1
    if sprite>5 then
      sprite2=sprite2+1
    end
    PopeyeAnimationTime = 0
  end
  if sprite>5 then
    SpecialEffects=5
    SpecialEffectX=130
  end
  if sprite>7 and GenericVariable==0 then
    sprite=7
  end
  if sprite2>26 then
    SpecialEffects=0
    GenericVariable=1
  end
  if sprite > 8 then
    sprite=1
    PopeyeAttacktype=0
    GenericVariableAtk=0
    sprite2=0
    GenericVariable=0
    SpecialEffects=0
    SpecialEffectX=0
    PopeyeState=1
  end
end
function PopeyeAirHeavy(dt)
  if GenericVariableAtk==0 then
    sprite=1
    sprite2=18
    GenericVariableAtk=1
  end
  PopeyeAttacktype=3
  PopeyeState=6
  anim_type=29
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.08 then
    sprite=sprite+1
    if sprite>4 and sprite<12 then
      GenericVariable=GenericVariable+math.pi/4
    end
    if sprite>12 then
      SpecialEffectX=60
      SpecialEffectY=40
      sprite2=sprite2+1
    end
    PopeyeAnimationTime = 0
  end
  if sprite>1 then
    SpecialEffects=6
    if GenericVariableAtk==1 then
      SpecialEffectX=30
      SpecialEffectY=-30
      GenericVariableAtk=2
    end
  end
  if sprite>4 and sprite<12 then
    if GenericVariableAtk==2 then
      sprite2=17
      GenericVariableAtk=3
    end
    SpecialEffectX=math.cos(GenericVariable)*30
    SpecialEffectY=math.sin(GenericVariable)*30
  end
  if sprite==12 then
    GenericVariable=0
    sprite2=18
    SpecialEffectX=30
    SpecialEffectY=-10
  end
  if sprite>15 and GenericVariable==1 then
    sprite=15
  end
  if sprite2>23 then
    GenericVariable=2
  end
  if sprite > 16 then
    sprite=1
    PopeyeAttacktype=0
    GenericVariableAtk=0
    SpecialEffects=0
    SpecialEffectX=0
    SpecialEffectY=0
    sprite2=0
    GenericVariable=0
    PopeyeState=1
  end
end
function PopeyeSpecial(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeXSpeed=0
  SpecialEffects=7
  PopeyeAttacktype=4
  PopeyeState=5
  anim_type=30
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.15 then
    sprite=sprite+1
    if GenericVariable==1 then
      sprite2=sprite2+1
    end
    PopeyeAnimationTime = 0
  end
  if sprite<5 then
    sprite2=9
    SpecialEffectX=-50
    SpecialEffectY=0
  end
  if sprite>4 and GenericVariable==0 then
    sprite2=10
    GenericVariable=1
    SpecialEffectX=100
    SpecialEffectY=-50
  end
  if sprite>7 and GenericVariable==1 then
    sprite=7
  end
  if sprite2>14 then
    GenericVariable=2
    SpecialEffects=0
  end
  if sprite > 8 then
    sprite=1
    PopeyeState=0
    PopeyeAttacktype=0
    GenericVariableAtk=0
    SpecialEffects=0
    SpecialEffectX=0
    SpecialEffectY=0
    sprite2=0
    GenericVariable=0
  end
end
function PopeyeSuper(dt)
  if GenericVariableAtk==0 then
    sprite=1
    GenericVariableAtk=1
  end
  PopeyeXSpeed=0
  PopeyeAttacktype=5
  PopeyeState=5
  anim_type=31
  PopeyeAnimationTime=PopeyeAnimationTime+dt
  if PopeyeAnimationTime > 0.10 then
    sprite=sprite+1
    if sprite>7 then
      if GenericVariable == 0 then
        sprite2=13
        GenericVariable=1
      end
      SpecialEffects=8
      SpecialEffectX=130
      sprite2=sprite2+1
    end
    PopeyeAnimationTime = 0
  end
  if sprite>9 and GenericVariable==1 then
    sprite=9
  end
  if sprite2>30 then
    SpecialEffects=0
    GenericVariable=2
  end
  if sprite > 12 then
    sprite=1
    PopeyeAttacktype=0
    PopeyeState=0
    GenericVariableAtk=0
    sprite2=0
    GenericVariable=0
    SpecialEffects=0
    SpecialEffectX=0
  end
end
function love.update(dt)
  Charbx=Charbx+PopeyeXSpeed*dt
  PopeyeYSpeed=PopeyeYSpeed+PopeyeGravity*500*dt
  Charby=Charby+PopeyeYSpeed*dt
  if Charby>StageHeight then
    Charby=StageHeight
    PopeyeYSpeed=0
    if PopeyeState==1 or PopeyeState==6 then
      PopeyeLanding(dt)
      PopeyeAttacktype=0
      sprite2=0
      SpecialEffects=0
      GenericVariableAtk=0
      SpecialEffects=0
      SpecialEffectX=0
      SpecialEffectY=0
    end
  end
  if PopeyeState == 0 then
    if love.keyboard.isDown("z") then
      PopeyeNeutralWeak(dt)
    elseif love.keyboard.isDown("x") then
      PopeyeNeutralMedium(dt)
    elseif love.keyboard.isDown("c") then
      PopeyeNeutralHeavy(dt)
    elseif love.keyboard.isDown("a") then
      PopeyeSpecial(dt)
    elseif love.keyboard.isDown("s") then
      PopeyeSuper(dt)
    elseif love.keyboard.isDown("right") then
      PopeyeWalkForward(dt)
      if love.keyboard.isDown("up") then
        sprite=1
        PopeyeJumpForward(dt)
      elseif love.keyboard.isDown("d") then
        PopeyeDashForward(dt)
      end
    elseif love.keyboard.isDown("left") then
      PopeyeWalkBackward(dt)
      if love.keyboard.isDown("up") then
        sprite=1
        PopeyeJumpBackward(dt)
      elseif love.keyboard.isDown("d") then
        PopeyeDashBackward(dt)
      end
    elseif love.keyboard.isDown("down") then
      sprite=1
      PopeyeCrouch(dt)
    elseif love.keyboard.isDown("up") then
      sprite=1
      PopeyeJump(dt)
    else
      PopeyeStand(dt)
    end
  elseif PopeyeState == 1 then
    if PopeyeYSpeed<0 then
      if love.keyboard.isDown("left") then
        PopeyeJumpBackward(dt)
      elseif love.keyboard.isDown("right") then
        PopeyeJumpForward(dt)
      else PopeyeJump(dt)
      end
    end
    if PopeyeYSpeed>0 then
      PopeyeFalling(dt)
    end
    if love.keyboard.isDown("z") then
      PopeyeAirWeak(dt)
    elseif love.keyboard.isDown("x") then
      PopeyeAirMedium(dt)
    elseif love.keyboard.isDown("c") then
      PopeyeAirHeavy(dt)
    end
  elseif PopeyeState == 3 then
    if love.keyboard.isDown("up") then
      PopeyeGettingBackUp(dt)
    end
  elseif PopeyeState==4 then
    if Guardtype==0 then
      PopeyeGuard(dt)
    elseif Guardtype==1 then
      PopeyeCrouchGuard(dt)
    end
  elseif PopeyeState == 5 then
    if PopeyeAttacktype == 1 then
      PopeyeNeutralWeak(dt)
    elseif PopeyeAttacktype == 2 then
      PopeyeNeutralMedium(dt)
    elseif PopeyeAttacktype == 3 then
      PopeyeNeutralHeavy(dt)
    elseif PopeyeAttacktype == 4 then
      PopeyeSpecial(dt)
    elseif PopeyeAttacktype == 5 then
      PopeyeSuper(dt)
    end
  elseif PopeyeState == 6 then
    if PopeyeAttacktype == 1 then
      PopeyeAirWeak(dt)
    elseif PopeyeAttacktype == 2 then
      PopeyeAirMedium(dt)
    elseif PopeyeAttacktype == 3 then
      PopeyeAirHeavy(dt)
    end
  elseif PopeyeState==8 then
    if PopeyeAttacktype == 1 then
      PopeyeCrouchingWeak(dt)
    elseif PopeyeAttacktype == 2 then
      PopeyeCrouchingMedium(dt)
    elseif PopeyeAttacktype == 3 then
      PopeyeCrouchingHeavy(dt)
    end
  elseif PopeyeState == 7 then
    if love.keyboard.isDown("down") then
      PopeyeCrouch(dt)
      if love.keyboard.isDown("z") then
        PopeyeCrouchingWeak(dt)
      elseif love.keyboard.isDown("x") then
        PopeyeCrouchingMedium(dt)
      elseif love.keyboard.isDown("c") then
        PopeyeCrouchingHeavy(dt)
      end
    else
      PopeyeStandUp(dt)
    end
  elseif PopeyeState==9 then
    if GenericVariable==1 then
      PopeyeDashForward(dt)
    elseif GenericVariable==2 then
      PopeyeDashBackward(dt)
    end
  end
  if EnemyState==5 or EnemyState==6 or EnemyState==8 then
    if love.keyboard.isDown("left") and PopeyeState==0 then
      PopeyeGuard(dt)
    elseif love.keyboard.isDown("left") and PopeyeState==7 then
      PopeyeCrouchGuard(dt)
    end
  end



end


function love.draw(--[[charb_x, charb_y, prop]])
  if SpecialEffects==1 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx, Charby, 0, 1, 1, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx-75, Charby-60, hitboxX+150, hitboxY+100)
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==2 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx+SpecialEffectX-15, Charby+SpecialEffectY-15, hitboxX+30, hitboxY+30)
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==3 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 0.6, 0.6, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2+1], Charbx+SpecialEffectX+-40, Charby+SpecialEffectY+40, 0, 0.6, 0.6, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY+40, 0, 0.6, 0.6, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX-40, Charby+SpecialEffectY, 0, 0.6, 0.6, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx-25, Charby-30, hitboxX+40, hitboxY+40)
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==4 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, GenericVariable, 0.5, 0.5, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()/2))
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx+SpecialEffectX-50, Charby+SpecialEffectY-50, hitboxX+35, hitboxY+25)
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==5 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", Charbx+SpecialEffectX-75, Charby+SpecialEffectY-15, hitboxX+35, hitboxY+25)
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==6 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX+33, Charby+SpecialEffectY+33, GenericVariable, 1, 1, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth())/2+30, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight())/2+40)
    love.graphics.setColor(255,0,0)
    if sprite>1 and sprite<5 then
      love.graphics.rectangle("line", Charbx+20, Charby-85, hitboxX-40, hitboxY+25)
    end
    if sprite<8 and sprite>4 then
      love.graphics.rectangle("line", Charbx+40, Charby-10, hitboxX, hitboxY+50)
    end
    if sprite>6 and sprite<10 then
      love.graphics.rectangle("line", Charbx+-25, Charby+50, hitboxX+50, hitboxY)
    end
    if  sprite>8 and sprite<12 then
      love.graphics.rectangle("line", Charbx-50, Charby-10, hitboxX, hitboxY+50)
    end
    if  sprite>12 and sprite<16 then
      love.graphics.rectangle("line", Charbx+30, Charby+40, hitboxX+10, hitboxY+20)
    end
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==7 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    if sprite2>9 then
    love.graphics.rectangle("line", Charbx+SpecialEffectX-20, Charby+SpecialEffectY-10, hitboxX+75, hitboxY+70)
    end
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==8 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][32], 400, 300, 0, 3.2, 3.2, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight())/2)
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
    love.graphics.setColor(255,0,0)
    love.graphics.rectangle("line", 0, 0, 800, 600)
    love.graphics.setColor(255,255,255)
  elseif SpecialEffects==9 then
    love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite2], Charbx+SpecialEffectX, Charby+SpecialEffectY, 0, 1, 1, (PopeyeAnimationFrame[anim_type][sprite2]:getWidth()-PopeyeAnimationFrame[anim_type][sprite]:getWidth())/2, (PopeyeAnimationFrame[anim_type][sprite2]:getHeight()-PopeyeAnimationFrame[anim_type][sprite]:getHeight())/2)
  end
  
  love.graphics.draw(PopeyeAnimationFrame[anim_type][sprite], Charbx, Charby--[[, 0, prop]])
  love.graphics.rectangle("line", Charbx, Charby, hitboxX, hitboxY)
  love.graphics.setColor(0,0,255)
  love.graphics.rectangle("line", Charbx, Charby+5, hitboxX-10, hitboxY-10)
  love.graphics.setColor(255,255,255)
end
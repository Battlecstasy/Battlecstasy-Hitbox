
local ky_vida=100
local ky_velocidade=1
local ky_gravidade=1
local ky_andar=100
local ky_anim_frame = 1
local ky_pos_x = 200
local ky_pos_y = 400
local ky_walk = {}
local ky_anim_time = 0
local ky_crouch = {}
local ky_butpressed = false
local ky_anim_type = {0,0}
local ky_anim_timepassed = {0.11, 0.09, 0.15, 0.09}
local isAttacking
local wry
local kysize = 0.8 

function love.load()
  for x = 1, 199 do -- carrega as imagens da animação
    ky_walk[x] = love.graphics.newImage("kyImagens/ky (" .. (x) .. ").png")
  end
end

function love.update(dt)
  if love.keyboard.isDown("right") and not isAttacking then
    ky_pos_x = ky_pos_x + (150 * dt*kysize) -- movimenta o personagem
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.11 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame > 5 then
      ky_anim_frame = 1
    end
  

  elseif love.keyboard.isDown ("left") and not isAttacking  then
    ky_pos_x = ky_pos_x + (-140 * dt*kysize) -- movimenta o personagem
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 6 or ky_anim_frame > 18 then
      ky_anim_frame = 7
    end
   elseif isAttacking then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame == 111 then
     wry = true
   end
    if ky_anim_frame == 112  and wry then
     ky_pos_x = ky_pos_x + 100*kysize
     wry = false
   end
    if ky_anim_frame == 117 then
      wry= true
     end
    if ky_anim_frame == 118 and wry then
     ky_pos_x = ky_pos_x - 1000*dt*kysize
     wry = false
     end
    if ky_anim_frame < 108 or ky_anim_frame > 121 then
    ky_anim_frame = 109
    end
    if ky_anim_frame == 120 then 
    isAttacking = false
    end


  elseif love.keyboard.isDown("down") and not isAttacking  then
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.15 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 39 then
      ky_anim_frame = 39
    end
   if ky_anim_frame == 44 then
      ky_anim_frame = 42
    end
    if ky_anim_frame > 44 then
      ky_anim_frame = 39
    end
  else
    ky_anim_time = ky_anim_time + dt
    if ky_anim_time > 0.09 then -- quando acumular mais de 0.1
      ky_anim_frame = ky_anim_frame + 1 -- avança para proximo frame
      ky_anim_time = 0
    end
    if ky_anim_frame < 21 or ky_anim_frame > 29 then
      ky_anim_frame = 21
    end
end
 
end

function love.keypressed(key)
  if(key == "a" and not isAttacking) then
    isAttacking = true
  end  
end

function love.draw() -- desenha o personagem usando o indice da animação
  love.graphics.draw(ky_walk[ky_anim_frame], ky_pos_x, ky_pos_y, 0, kysize, kysize, ky_walk[ky_anim_frame]:getWidth(), ky_walk[ky_anim_frame]:getHeight())
  --love.graphics.draw(ky_crouch[ky_anim_frame], ky_pos_x, ky_pos_y)
end
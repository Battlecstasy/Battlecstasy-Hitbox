local cirno = require("c1")
local pos_chao = 300

function love.load()
  cirno:new(pos_chao)
end

function love.update(dt)
  cirno:update(dt)
end

function love.draw()
  cirno:draw()
end
local cirnosprite
function love.load()
  cirnosprite =love.graphics.newImage("Cirno/Walk Forward/Cirno1.png")
end

function love.draw()
  love.graphics.draw(cirnosprite,400,300)
end
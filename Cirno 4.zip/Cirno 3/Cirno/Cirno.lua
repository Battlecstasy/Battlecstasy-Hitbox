local Cirno = {}
local CirnoWalkSpeed = 1.2
local CirnoWalkSpeedBack = 1.2
local CirnoDashSpeed = 1.2
local CirnoGravity = 0.8
local CirnoJump = 1.1 
local CirnoHP = 90
local CirnoAnimationFrame ={}
local CirnoAnimationTime = 0
local animationsize = {8,8,2,6,9,3,2,2,6,3,4,4,7,8,5,2,7,5,8,4,6,6,13,5,13,14,10,26,23,14,32}
local Cirno_count = 1

function Cirno:new()
  for i=1,31 do
    for j=1,animationsize[i] do
      CirnoAnimationFrame[i][j]={love.graphics.newImage("Cirno/Cirnosprite/Cirno"..Cirno_count..".png")}
      Cirno_count=Cirno_count+1
    end
  end
end

function CirnoWalkForward()
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 8 then
    sprite= 1
  end
end

function CirnoWalkBackward()
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 8 then
    sprite= 1
  end
end

function CirnoStandUp()
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 2 then
    sprite= 1
  end
end

function CirnoStand()
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 6 then
    sprite= 1
  end
end

function CirnoLanding()
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 3 then
    sprite= 1
  end
end
function CirnoLandingOnGround()
  CirnoAnimationTime=CirnoAnimationTime+dt
  if CirnoAnimationTime > 0.15 then
    sprite=sprite+1
  end
  if sprite > 9 then
    sprite=9
  end
end
function Cirno:update(dt)
  if love.keyboard.isDown(right) then
      CirnoWalkForward()
    end
  end
end

function Cirno:draw(anim_type, sprite, charb_x, charb_y, prop)
  love.graphics.draw(CirnoAnimationFrame[anim_type][sprite], charb_x, charb_y, 0, prop)
end
return Cirno
local Cirno = {}
local CirnoWalkSpeed = 1.1
local CirnoWlakSpeedBack = 1.1
local CirnoDashSpeed = 1.2
local CirnoGravity = 0.8
local CirnoJump = 1.1 
local CirnoHP = 92
local CirnoAnimationFrame 
function Cirno:new()
 for i=1,265 do
   CirnoAnimationFrame={love.graphics.newImage("Cirno/Cirnosprite/Cirno"..i)
  end
end

function Cirno:draw(sprite, charb_x, charb_y, prop)
  love.graphics.draw(CirnoAnimationFrame[sprite], charb_x, charb_y, 0, prop)
end
return Cirno
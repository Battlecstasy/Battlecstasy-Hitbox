local Popeye_vida=100
local Popeye_velocidade=1
local Popeye_gravidade=1
local Popeye_andar=100
local Popeye_anim_frame = 1
local Popeye_pos_x = 30
local Popeye_pos_y = 50
local Popeye_walk = {}
local Popeye_anim_time = 0

function love.load()
  for x = 1, 9,1 do -- carrega as imagens da animação
    Popeye_walk[x] = love.graphics.newImage("Walk_11-01" .. (x) .. ".png")
    
  end   
end


function love.update(dt)
  if love.keyboard.isDown("right") then
    Popeye_pos_x = Popeye_pos_x + (100 * dt) -- movimenta o personagem
    Popeye_anim_time = Popeye_anim_time + dt
    if Popeye_anim_frame > 8 then
      Popeye_anim_frame = 1
    end
  end
  if love.keyboard.isDown("left") then
    Popeye_pos_x = Popeye_pos_x + (-100 * dt) -- movimenta o personagem
    Popeye_anim_time = Popeye_anim_time + dt
    if Popeye_anim_frame > 8 then
      Popeye_anim_frame = 1
    end
  end
  
  
  if Popeye_anim_time > 0.06 then -- quando acumular mais de 0.1
    Popeye_anim_frame = Popeye_anim_frame + 1 -- avança para proximo frame
    Popeye_anim_time = 0
  end
end

function love.draw() -- desenha o personagem usando o indice da animação
  love.graphics.draw(Popeye_walk[Popeye_anim_frame], Popeye_pos_x, Popeye_pos_y)
end
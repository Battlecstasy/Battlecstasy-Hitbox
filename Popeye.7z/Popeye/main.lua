local health=110
local speed=0,95
local grav=1
local popeye_walk={}
local popeye_attack_aereo={}
local popeye_attack_forte={}
local popeye_attack_super={}
local popeye_attack_special={}
local popeye_attack_leve={}
local popeye_attack_medio={}
local popeye_anim_frame=1
local popeye_pos_x = 30
local popeye_pos_y = 400
local popeye_anim_time=0
local popeye_stand={}


function love.load()
  for x=1,9,1 do
    popeye_walk[x]=love.graphics.newImage("Walk_11-0"..x..".png")  
  end
  for x=1,4,1 do
   popeye_attack_leve[x]=love.graphics.newImage("Leve_200-0"..x..".png")
  end
end

function love.update(dt)
  if love.keyboard.isDown("right","d") then
    popeye_pos_x= popeye_pos_x+(100*dt)
    popeye_anim_time = popeye_anim_time + dt
    if popeye_anim_time > 0.12 then 
      popeye_anim_frame = popeye_anim_frame + 1 
      if popeye_anim_frame>9 then
        popeye_anim_frame=1
      end              
      popeye_anim_time=0
    end
  end  
  if love.keyboard.isDown("left","a") then
    popeye_pos_x= popeye_pos_x+(-100*dt)
    popeye_anim_time = popeye_anim_time + dt
    if popeye_anim_time > 0.12 then 
      popeye_anim_frame = popeye_anim_frame + 1 
      if popeye_anim_frame>9 then
        popeye_anim_frame=1
      end              
      popeye_anim_time=0
    end
  end  
end

function love.keypressed(key)
   if key == "f" then
     popeye_anim_frame = 1
      love.graphics.draw(popeye_attack_leve[popeye_anim_frame])
   end
   if key == "escape" then
      love.event.quit()
   end
end

function love.keyreleased(key)
  if key == "right" or key == "d" then
    popeye_anim_frame = 1
  end
end

function love.draw()
  love.graphics.draw(popeye_walk[popeye_anim_frame],popeye_pos_x,popeye_pos_y)
end                                                  

local popeye_walk = {}
local popeye_anim_frame=1
local popeye_speed= 1
local popeye_attack ={}
local popeye_jumph={}
local popeye_gravity=1
local popeye_anim_time=0
local popeye_hp=100
local popeye_super_special={}

function love.load()
  for x=1,10,1 do
    popeye_walk[x]=love.graphics.newImage("Walk_11-0"..x..".png")
    popeye_attack[x]=love.graphics.newImage("Popeye_11-0"..x..".png")
    popeye_jumph[x]=love.graphics.newImage("Jump_0-01"..x..".png")
  end
  
  
end
function :new
 
   
      
 end
 
 function love.update(dt)
 
   

end